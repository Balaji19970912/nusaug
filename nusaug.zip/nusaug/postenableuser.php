<?php

    include 'dbconn.php';

        $emailid=$_POST["emailId"];
        $verifyuserstatus = 'Active';

        $sql = "UPDATE nususerdata SET active ='".$verifyuserstatus."' WHERE emailId='".$emailid."'";
        $conn->query($sql);
        
echo "<script>
        alert('User activated'); 
        window.history.go(-2);
</script>";
?>