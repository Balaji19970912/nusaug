<?php 
require_once('./dbconn.php');
class libFunc
{	

	public static function getclientname($clintId){
		global $conn;
		$countryName ='';
		$getUserRole = "SELECT clientcompany FROM clientcompanydata WHERE id=".$clintId."";
        $result = $conn->query($getUserRole);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
               $countryName = $row['clientcompany'];
            }
        }
		return $countryName;
	}
	public static function getclientdata($clinetid){
		global $conn;
		$getdatas = "SELECT nc.clientcompany, ncs.countryName FROM clientcompanydata nc LEFT JOIN nus_countries ncs ON ncs.countryId=nc.country WHERE nc.id=".$clinetid."";
		$result = $conn->query($getdatas);
		$clientname = array();
		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
			    $clientname[] = $row;
			    
			}
		}
		return $clientname;
	}
	public static function getparentname($clientId){
		global $conn;
		$getdatas = "SELECT parentcompany  FROM clientcompanydata WHERE id=".$clientId."";
		$result = $conn->query($getdatas);
		$parentname = '';
		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
			   $parentname = $row['parentcompany'];
			}
		}
		return $parentname;
	}
	public static function getcountclient($parentname){
		global $conn;
		$getdatas = "SELECT COUNT(clientcompany) as counts FROM clientcompanydata WHERE parentcompany='".$parentname."'";
		$result = $conn->query($getdatas);
		$parentname = 0;
		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
			   $parentname = $row['counts'];
			}
		}
		return $parentname;
	}
	
	
}


?>

